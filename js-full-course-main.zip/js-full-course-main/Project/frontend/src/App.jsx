import React from 'react'
import Login from './components/Login';
import Signup from './components/Signup';
import Home from './components/Home';
import { Routes, Route, Navigate } from 'react-router-dom';
function App() {
  const user=localStorage.getItem("user")
  return (
    <div>
       <Routes>
      <Route path="/" element={user? <Home /> : <Navigate to="/login"/>} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />

    </Routes>
    </div>
  )
}

export default App