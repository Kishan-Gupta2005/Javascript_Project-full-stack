import React, { useState, useEffect } from "react";
import logo from '../assets/lc.png'
import photo from "../assets/image.svg"
import { useNavigate } from "react-router-dom";
function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const navigate = useNavigate();

  // Check login status on load
  useEffect(() => {
    const user = localStorage.getItem("user");
    setIsLoggedIn(!!user);
  }, []);

  // Scroll logic
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("user");
    setIsLoggedIn(false);
     navigate("/login");
  };

  return (
    <div className="w-full">

      {/* Header */}
     <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${scrolled ? "bg-white shadow-md" : "bg-transparent"}`}>
        <div className="flex justify-between items-center px-6 py-4">

          {/* Logo */}
          <div className="flex items-center gap-2">
            <img src={logo} alt="Logo" className="h-6 w-6" />
            <span className="font-semibold">Learn Coding</span>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex gap-6 items-center">
            <a href="/about">About</a>
            <a href="/contact">Contact</a>
            <a href="/media">Media</a>

            {isLoggedIn ? (
              <button 
                onClick={handleLogout}
                className="bg-red-500 text-white px-3 py-1 rounded"
              >
                Logout
              </button>
            ) : (
              <a href="/login" className="bg-blue-500 text-white px-3 py-1 rounded">
                Login
              </a>
            )}
          </nav>

          {/* Hamburger */}
          <div
            className="md:hidden flex flex-col gap-1 cursor-pointer"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            <span className={`block w-6 h-0.5 bg-black transition ${menuOpen && "rotate-45 translate-y-1.5"}`}></span>
            <span className={`block w-6 h-0.5 bg-black ${menuOpen && "hidden"}`}></span>
            <span className={`block w-6 h-0.5 bg-black transition ${menuOpen && "-rotate-45 -translate-y-1.5"}`}></span>
          </div>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="md:hidden flex flex-col items-center gap-4 pb-4">
            <a href="/about">About</a>
            <a href="/contact">Contact</a>
            <a href="/media">Media</a>

            {isLoggedIn ? (
              <button 
                onClick={handleLogout}
                className="bg-red-500 text-white px-3 py-1 rounded"
              >
                Logout
              </button>
            ) : (
              <a href="/login" className="bg-blue-500 text-white px-3 py-1 rounded">
                Login
              </a>
            )}
          </div>
        )}
      </header>
      {/* Hero Section */}
      <section className="pt-24 px-6 md:px-16 flex flex-col md:flex-row items-center gap-10">

        {/* Left */}
        <div className="flex-1 w-1/2">
          <h1 className="text-4xl font-bold mb-4">Welcome to Our Website</h1>
          <p className="mb-4">
            This landing page includes extra content so the footer naturally stays at the bottom.
          </p>

          <h3 className="text-xl font-semibold mt-4">Our Mission</h3>
          <p className="mt-2">
            We aim to deliver the simplest example website built using pure HTML.
          </p>
          <p className="mt-2">
            You can continue adding text, paragraphs, lists, or images.
          </p>
          <p className="mt-2">
            Clean, beginner-friendly and easy to understand.
          </p>
           <p className="mt-2">
            We aim to deliver the simplest example website built using pure HTML.
          </p>
          <p className="mt-2">
            You can continue adding text, paragraphs, lists, or images.
          </p>
          <p className="mt-2">
            Clean, beginner-friendly and easy to understand.
          </p>
        </div>

        {/* Right */}
        <div className="flex-1 text-center">
          <img src={photo} alt="HTML Figure" className="mx-auto w-full" />
          <h3 className="mt-2 text-gray-600">Figure: HTML</h3>
        </div>
      </section>

      {/* Testimonials */}
      <section className="px-6 md:px-16 mt-16">
        <h2 className="text-2xl font-bold text-center mb-8">What Our Students Say</h2>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            { text: "This channel helped me understand coding basics!", name: "Akhilesh" },
            { text: "Clean content and beginner-friendly.", name: "Ankush" },
            { text: "Amazing resource for web development!", name: "Vikash" },
            { text: "Really helpful and simple.", name: "Sourabh" },
            { text: "Best place to start coding.", name: "Vivek" }
          ].map((item, index) => (
            <div key={index} className="p-4 border rounded-lg shadow-sm">
              <p>"{item.text}"</p>
              <h4 className="mt-2 font-semibold">- {item.name}</h4>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-16 border-t text-center py-6">
        <p>© 2025 | All Rights Reserved</p>
      </footer>
    </div>
  );
}

export default Home;