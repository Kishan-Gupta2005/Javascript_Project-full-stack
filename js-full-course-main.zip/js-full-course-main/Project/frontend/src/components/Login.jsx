import axios from "axios"
import { useForm } from "react-hook-form"
import { Link, useNavigate, } from 'react-router-dom'

function Login() {
    const navigate=useNavigate()
    const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm()

  const onSubmit = async(data) => {
    console.log(data);
    try {
       const res= await axios.post('http://localhost:4001/user/login',{
            email:data.email,
            password:data.password
        })
        localStorage.setItem("user",JSON.stringify(res.data.user))
        navigate("/")
        alert(res.data.message)
    } catch (error) {
         if(error.response){
            alert(error.response.data.error)
        }else{
            alert("something went wrong!")
        }
    }
  }
    return (
       <form onSubmit={handleSubmit(onSubmit)}>
         <div className=' min-h-screen bg-gray-200 flex items-center justify-center'>
            <div className=' bg-gray-100 w-full max-w-md p-8 rounded-2xl shadow-md'>
                {/* Heading */}
                <h1 className=' text-3xl font-semibold text-center mb-8'>Login</h1>

                {/* Email */}
                <div className='mb-5'>
                    <label className=' text-gray-700 font-medium' >Email</label>
                    <input {...register("email", { required: true })} type="email" placeholder='Enter email' className=' w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-300' />
                    {errors.email && <span className=" text-red-600 font-semibold text-sm">This field is required</span>}
                </div>

                {/* Password */}
                <div className='mb-5'>
                    <label className=' text-gray-700 font-medium' >Password</label>
                    <input {...register("password", { required: true })} type="password" placeholder='Enter Password' className=' w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-300' />
                    {errors.password && <span className=" text-red-600 font-semibold text-sm">This field is required</span>}
                </div>

                {/* Button */}
                <button type='submit' className=' w-full bg-blue-500 text-white py-3 rounded-xl text-lg font-medium hover:bg-blue-700 transition'>Login</button>

                {/* Signup Navigation */}
                <p className=' text-center mt-5 text-gray-700'>
                    New account?{" "}
                    <Link to="/signup" className=' text-blue-500 cursor-pointer hover:underline'>Signup here</Link>
                </p>
            </div>
        </div>
       </form>
    )
}

export default Login