import { useForm } from "react-hook-form"
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios'
function Signup() {

    const navigate=useNavigate()

     const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm()

  const onSubmit =async (data) => {
    console.log(data);
    try {
        if(data.password !== data.confirmPassword){
            alert("Password do not match")
            return
        }

       const res= await axios.post('http://localhost:4001/user/signup',{
            username:data.username,
            email:data.email,
            password:data.password,
            confirmPassword:data.confirmPassword
        })
        alert(res.data.message)
        navigate("/login")

    } catch (error) {
        if(error.response){
            alert(error.response.data.error)
        }else{
            alert("something went wrong!")
        }
    }
  }
    return (
      <form onSubmit={handleSubmit(onSubmit)}>
          <div className=' min-h-screen bg-gray-200 flex items-center justify-center'>
            <div className=' bg-gray-100 w-full max-w-md p-8 rounded-2xl shadow-md'>
                {/* Heading */}
                <h1 className=' text-3xl font-semibold text-center mb-8'>Signup</h1>

                {/* Username */}
                <div className='mb-5'>
                    <label className=' text-gray-700 font-medium' >Username</label>
                    <input {...register("username", { required: true })} type="text" placeholder='Enter username' className=' w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-300' />
                    {errors.username && <span className=" text-red-600 font-semibold text-sm">This field is required</span>}
                </div>

                {/* Email */}
                <div className='mb-5'>
                    <label className=' text-gray-700 font-medium' >Email</label>
                    <input  {...register("email", { required: true })} type="email" placeholder='Enter email' className=' w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-300' />
                    {errors.email && <span className=" text-red-600 font-semibold text-sm">This field is required</span>}
                </div>

                {/* Password */}
                <div className='mb-5'>
                    <label className=' text-gray-700 font-medium' >Password</label>
                    <input  {...register("password", { required: true })} type="password" placeholder='Enter Password' className=' w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-300' />
                    {errors.password && <span className=" text-red-600 font-semibold text-sm">This field is required</span>}
                </div>

                {/* Confirm Password */}
                <div className='mb-5'>
                    <label className=' text-gray-700 font-medium' >Confirm Password</label>
                    <input  {...register("confirmPassword")} type="password" placeholder='Re-type Password' className=' w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-300' />
                    {errors.confirmPassword && <span className=" text-red-600 font-semibold text-sm">This field is required</span>}
                </div>

                {/* Button */}
                <button type="submit" className=' w-full bg-blue-500 text-white py-3 rounded-xl text-lg font-medium hover:bg-blue-700 transition'>Signup</button>

                {/* Signup Navigation */}
                <p className=' text-center mt-5 text-gray-700'>
                    Have an account?{" "}
                    <Link to="/login" className=' text-blue-500 cursor-pointer hover:underline'>Login</Link>
                </p>
            </div>
        </div>
      </form>
    )
}

export default Signup