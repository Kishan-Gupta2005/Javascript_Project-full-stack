import express from 'express'
import dotenv from 'dotenv'
import mongoose from 'mongoose'
import userRoutes from './route/user.route.js'
import cors from 'cors'
dotenv.config()
const app = express()
const port = process.env.PORT || 3000

// Database Connection Code.
const connectDB=async()=>{
  try {
    await mongoose.connect(process.env.DB_URL)
    console.log("Connected to MongoDB")
  } catch (error) {
    console.error(`Error: ${error.message}`)
  }
}

connectDB()

// routes
app.use(express.json())
app.use(cors())
app.use("/user",userRoutes)


app.listen(port, () => {
  console.log(`Server is running on port ${port}`)
})
