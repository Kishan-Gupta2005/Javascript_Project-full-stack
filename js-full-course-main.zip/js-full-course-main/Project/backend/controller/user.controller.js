import User from "../model/user.schema.js"

export const signup=async(req,res)=>{
   try {
        const {username,email,password,confirmPassword}=req.body

        if(!username || !password || !email || !confirmPassword){
            return res.status(400).json({message:"All fields are required"})
        }

        if(password!=confirmPassword){
             return res.status(400).json({message:"Password do not match"})
        }
        const existUser=await User.findOne({email})
        if(existUser){
            return res.status(400).json({message:"User already exist"})
        }

        const user=await User.create({
            username,
            email,
            password
        })
        return res.status(201).json({message:"User registered successfully" })
   } catch (error) {
    return res.status(501).json({error:error.message})
   }
}

export const login=async(req,res)=>{
    try {
        const {email,password}=req.body

        if(!email || !password){
            return res.status(400).json({message:"All fields are required"})
        }
        const user=await User.findOne({email})
        if(!user || user.password!==password){
            return res.status(400).json({message:"Invalid credentials"})
        }

        res.status(201).json({
            message:"User logged in successfully",
            user
            
        })
    } catch (error) {
         return res.status(501).json({error:error.message})
    }
}